<?php
session_start();
$_SESSION['userid']="1";
echo  $_SESSION['userid'];
?>